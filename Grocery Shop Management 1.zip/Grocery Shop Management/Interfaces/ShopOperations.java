package Interfaces;
import java.lang.*;
import Classes.*;

public interface ShopOperations
{ 
 	void showShopInfo();
}