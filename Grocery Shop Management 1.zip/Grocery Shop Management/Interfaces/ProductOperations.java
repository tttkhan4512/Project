package Interfaces;
import java.lang.*;
import Classes.*;

public interface ProductOperations
{
	void insertProduct(Product p);
	void removeProduct(Product p);
	void showProductInfo();
}