package Classes;
import java.lang.*;
import Interfaces.*;

public class Onion extends Product
{
	public void  onionProduct()
	{
		super.showProductInfo();
	}

}
