package Classes;
import java.lang.*;
import Interfaces.*;

public class Oil extends Product
{
	public void  oilProduct()
	{
		super.showProductInfo();
	}

}
