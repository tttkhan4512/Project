package Classes;
import java.lang.*;
import Interfaces.*;

public class Rice extends Product
{
	public void  riceProduct()
	{
		super.showProductInfo();
	}
}