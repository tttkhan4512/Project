package Classes;
import java.lang.*;
import Interfaces.*;

public class Tea extends Product
{
	public void  teaProduct()
	{
		super.showProductInfo();
	}

}