package Classes;
import java.lang.*;
import Interfaces.*;

public class Bread extends Product
{
	public void  breadProduct()
	{
		super.showProductInfo();
	}
}