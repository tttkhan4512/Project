package Classes;
import java.lang.*;
import Interfaces.*;

public class Suger extends Product
{
	public void  sugerProduct()
	{
		super.showProductInfo();
	}
}