package Classes;
import java.lang.*;
import Interfaces.*;

public class Tomato extends Product
{
	public void  tomatoProduct()
	{
		super.showProductInfo();
	}

}
