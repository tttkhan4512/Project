package Classes;
import java.lang.*;
import Interfaces.*;

public class Salt extends Product
{
	public void  saltProduct()
	{
		super.showProductInfo();
	}

}
