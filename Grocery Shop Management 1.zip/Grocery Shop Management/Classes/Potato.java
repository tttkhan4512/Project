package Classes;
import java.lang.*;
import Interfaces.*;

public class Potato extends Product
{
	public void  potatoProduct()
	{
		super.showProductInfo();
	}

}
