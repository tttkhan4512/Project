package Classes;
import java.lang.*;
import Interfaces.*;

public class Egg extends Product
{
	public void  eggProduct()
	{
		super.showProductInfo();
	}
}
