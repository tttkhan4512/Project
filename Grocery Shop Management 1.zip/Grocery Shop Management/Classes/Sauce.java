package Classes;
import java.lang.*;
import Interfaces.*;

public class Sauce extends Product
{
	public void  sauceProduct()
	{
		super.showProductInfo();
	}

}