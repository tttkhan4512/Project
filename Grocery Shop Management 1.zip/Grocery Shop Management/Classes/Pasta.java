package Classes;
import java.lang.*;
import Interfaces.*;

public class Pasta extends Product
{
	public void  pastaProduct()
	{
		super.showProductInfo();
	}

}
